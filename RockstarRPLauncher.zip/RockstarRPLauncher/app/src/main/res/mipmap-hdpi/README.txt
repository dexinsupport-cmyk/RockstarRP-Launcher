Place your app icon here as ic_launcher.webp or png
