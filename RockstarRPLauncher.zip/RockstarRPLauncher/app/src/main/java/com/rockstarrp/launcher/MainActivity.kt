package com.rockstarrp.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RockstarTheme {
                LauncherScreen()
            }
        }
    }
}

@Composable
fun RockstarTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFE50914),
            onPrimary = Color.White,
            secondary = Color(0xFFB81D13),
            background = Color(0xFF0D0D0D),
            surface = Color(0xFF1A1A1A),
            onSurface = Color.White,
            surfaceVariant = Color(0xFF252525)
        ),
        content = content
    )
}

@Composable
fun LauncherScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val prefs = remember { context.getSharedPreferences("rockstar_prefs", Context.MODE_PRIVATE) }

    var nickname by remember { mutableStateOf(prefs.getString("nickname", "") ?: "") }
    var serverInfo by remember { mutableStateOf(ServerInfo()) }
    var isLoading by remember { mutableStateOf(false) }
    var lastUpdate by remember { mutableStateOf("") }

    fun saveNickname(name: String) {
        prefs.edit { putString("nickname", name) }
    }

    fun refreshServer() {
        scope.launch {
            isLoading = true
            serverInfo = SampQuery.queryInfo()
            isLoading = false
            lastUpdate = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                .format(java.util.Date())
        }
    }

    // Auto refresh every 15 seconds
    LaunchedEffect(Unit) {
        refreshServer()
        while (true) {
            delay(15000)
            refreshServer()
        }
    }

    fun connectToServer() {
        if (nickname.isBlank()) {
            Toast.makeText(context, "لطفاً نیک‌نیم خود را وارد کنید", Toast.LENGTH_SHORT).show()
            return
        }
        saveNickname(nickname)

        // Try multiple connection methods
        val methods = listOf(
            // Method 1: samp:// scheme
            {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("samp://5.57.37.215:7777"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            },
            // Method 2: Common SAMP packages
            {
                val packages = listOf(
                    "com.rockstargames.gtasa",
                    "com.samp.mobile",
                    "com.gta.game",
                    "com.samp.launcher",
                    "ru.edgar.space"
                )
                var launched = false
                for (pkg in packages) {
                    try {
                        val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                        if (launchIntent != null) {
                            launchIntent.putExtra("ip", "5.57.37.215")
                            launchIntent.putExtra("port", 7777)
                            launchIntent.putExtra("nickname", nickname)
                            context.startActivity(launchIntent)
                            launched = true
                            break
                        }
                    } catch (_: Exception) {}
                }
                if (!launched) throw Exception("No client found")
            }
        )

        var success = false
        for (method in methods) {
            try {
                method()
                success = true
                break
            } catch (_: Exception) {}
        }

        if (!success) {
            Toast.makeText(
                context,
                "کلاینت سمپ پیدا نشد!\nلطفاً ابتدا SA-MP Mobile را نصب کنید",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0D0D0D),
                        Color(0xFF1A0A0A),
                        Color(0xFF0D0D0D)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
                .statusBarsPadding()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Header
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "راکستار رول پلی",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE50914),
                textAlign = TextAlign.Center
            )
            Text(
                text = "Rockstar RolePlay",
                fontSize = 14.sp,
                color = Color(0xFFAAAAAA),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Server Status Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    // Status header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (serverInfo.isOnline) Color(0xFF4CAF50)
                                        else Color(0xFFE50914)
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (serverInfo.isOnline) "آنلاین" else "آفلاین",
                                color = if (serverInfo.isOnline) Color(0xFF4CAF50) else Color(0xFFE50914),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        IconButton(
                            onClick = { refreshServer() },
                            enabled = !isLoading
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color(0xFFE50914),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    Icons.Rounded.Refresh,
                                    contentDescription = "رفرش",
                                    tint = Color(0xFFE50914)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Hostname
                    Text(
                        text = serverInfo.hostname,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Players & Ping
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        StatusItem(
                            icon = Icons.Default.People,
                            label = "بازیکنان",
                            value = if (serverInfo.isOnline)
                                "${serverInfo.players} / ${serverInfo.maxPlayers}"
                            else "-"
                        )
                        StatusItem(
                            icon = Icons.Default.Speed,
                            label = "پینگ",
                            value = if (serverInfo.isOnline) "${serverInfo.ping} ms" else "-"
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Gamemode & Language
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        StatusItem(
                            icon = Icons.Default.SportsEsports,
                            label = "گیم‌مود",
                            value = serverInfo.gamemode
                        )
                        StatusItem(
                            icon = Icons.Default.Language,
                            label = "زبان",
                            value = serverInfo.language
                        )
                    }

                    if (lastUpdate.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "آخرین بروزرسانی: $lastUpdate",
                            fontSize = 11.sp,
                            color = Color(0xFF666666),
                            modifier = Modifier.align(Alignment.End)
                        )
                    }

                    if (serverInfo.error != null && !serverInfo.isOnline) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = serverInfo.error ?: "",
                            fontSize = 12.sp,
                            color = Color(0xFFFF6B6B),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Nickname Input
            OutlinedTextField(
                value = nickname,
                onValueChange = { nickname = it },
                label = { Text("نیک‌نیم شما") },
                placeholder = { Text("نام خود را وارد کنید") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFE50914),
                    unfocusedBorderColor = Color(0xFF444444),
                    focusedLabelColor = Color(0xFFE50914),
                    cursorColor = Color(0xFFE50914),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                leadingIcon = {
                    Icon(Icons.Default.Person, contentDescription = null, tint = Color(0xFFE50914))
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(
                    onDone = {
                        focusManager.clearFocus()
                        saveNickname(nickname)
                    }
                )
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Connect Button
            Button(
                onClick = { connectToServer() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFE50914)
                ),
                elevation = ButtonDefaults.buttonElevation(8.dp)
            ) {
                Icon(
                    Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "اتصال به سرور",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // IP Display
            Text(
                text = "5.57.37.215:7777",
                fontSize = 13.sp,
                color = Color(0xFF888888),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Quick Links
            Text(
                text = "لینک‌های مفید",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                LinkButton(
                    text = "دیسکورد",
                    icon = Icons.Default.Forum,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        // TODO: لینک دیسکورد رو اینجا بذار
                        Toast.makeText(context, "لینک دیسکورد را تنظیم کنید", Toast.LENGTH_SHORT).show()
                    }
                )
                LinkButton(
                    text = "قوانین",
                    icon = Icons.Default.Description,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        Toast.makeText(context, "لینک قوانین را تنظیم کنید", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                LinkButton(
                    text = "اینستاگرام",
                    icon = Icons.Default.PhotoCamera,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        Toast.makeText(context, "لینک اینستاگرام را تنظیم کنید", Toast.LENGTH_SHORT).show()
                    }
                )
                LinkButton(
                    text = "سایت",
                    icon = Icons.Default.Language,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        Toast.makeText(context, "لینک سایت را تنظیم کنید", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            Spacer(modifier = Modifier.height(40.dp))

            Text(
                text = "نسخه ۱.۰ • راکستار رول پلی",
                fontSize = 12.sp,
                color = Color(0xFF555555)
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun StatusItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(140.dp)
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = Color(0xFFE50914),
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color(0xFFAAAAAA)
        )
        Text(
            text = value,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun LinkButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = Color.White
        ),
        border = ButtonDefaults.outlinedButtonBorder.copy(
            brush = Brush.linearGradient(
                listOf(Color(0xFF444444), Color(0xFF333333))
            )
        )
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(text, fontSize = 13.sp)
    }
}
