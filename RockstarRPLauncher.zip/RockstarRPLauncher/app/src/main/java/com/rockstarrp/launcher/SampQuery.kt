package com.rockstarrp.launcher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class ServerInfo(
    val hostname: String = "در حال دریافت...",
    val players: Int = 0,
    val maxPlayers: Int = 0,
    val gamemode: String = "-",
    val language: String = "-",
    val passworded: Boolean = false,
    val ping: Long = 0,
    val isOnline: Boolean = false,
    val error: String? = null
)

object SampQuery {

    private const val SERVER_IP = "5.57.37.215"
    private const val SERVER_PORT = 7777

    suspend fun queryInfo(): ServerInfo = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        var socket: DatagramSocket? = null

        try {
            socket = DatagramSocket()
            socket.soTimeout = 4000

            val ipParts = SERVER_IP.split(".").map { it.toInt().toByte() }.toByteArray()

            // Packet: "SAMP" + IP (4 bytes) + Port (2 bytes little endian) + 'i'
            val packetData = ByteArray(11)
            packetData[0] = 'S'.code.toByte()
            packetData[1] = 'A'.code.toByte()
            packetData[2] = 'M'.code.toByte()
            packetData[3] = 'P'.code.toByte()
            System.arraycopy(ipParts, 0, packetData, 4, 4)
            packetData[8] = (SERVER_PORT and 0xFF).toByte()
            packetData[9] = ((SERVER_PORT shr 8) and 0xFF).toByte()
            packetData[10] = 'i'.code.toByte()

            val address = InetAddress.getByName(SERVER_IP)
            val sendPacket = DatagramPacket(packetData, packetData.size, address, SERVER_PORT)
            socket.send(sendPacket)

            val buffer = ByteArray(4096)
            val receivePacket = DatagramPacket(buffer, buffer.size)
            socket.receive(receivePacket)

            val ping = System.currentTimeMillis() - startTime
            val data = receivePacket.data
            val length = receivePacket.length

            // Parse response (skip first 11 bytes which are echo of request)
            var offset = 11

            fun readByte(): Int {
                val b = data[offset].toInt() and 0xFF
                offset++
                return b
            }

            fun readShort(): Int {
                val value = (data[offset].toInt() and 0xFF) or
                        ((data[offset + 1].toInt() and 0xFF) shl 8)
                offset += 2
                return value
            }

            fun readString(): String {
                val len = readByte()
                if (len <= 0 || offset + len > length) return ""
                val str = String(data, offset, len, Charsets.ISO_8859_1)
                offset += len
                return str
            }

            val passworded = readByte() != 0
            val players = readShort()
            val maxPlayers = readShort()
            val hostname = readString()
            val gamemode = readString()
            val language = readString()

            ServerInfo(
                hostname = hostname.ifEmpty { "راکستار رول پلی" },
                players = players,
                maxPlayers = maxPlayers,
                gamemode = gamemode.ifEmpty { "RolePlay" },
                language = language.ifEmpty { "Persian" },
                passworded = passworded,
                ping = ping,
                isOnline = true
            )
        } catch (e: Exception) {
            ServerInfo(
                hostname = "راکستار رول پلی",
                isOnline = false,
                error = e.message ?: "خطا در اتصال به سرور"
            )
        } finally {
            socket?.close()
        }
    }
}
